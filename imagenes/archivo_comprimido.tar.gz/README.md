Este directorio debería ser accesible dentro y fuera del contenedor.

* Las imágenes descargadas tendrían que ubicarse en esta carpeta.
* Dentro de esta carpeta, debería crearse el archivo comprimido con las
imágenes.
* Se incluyen algunas imágenes de ejemplo. Luego de ser etiquetadas deberían
crearse los siguientes archivos con estas etiquetas:
  - `375a650373d0f6bc68e3e31d383b23d3bfb451129d27bcab9053fd0cfb23ce85.tag`:
    `1 dog`
  - `3a3e648182c3332aa482a99a702d4388f94f79313d797f451cf59b39d80ee801.tag`:
    `no detections`
  - `3d4cb552bf2664dffe563d31571be927a1e47fb3cf1ce1bb7f184844c4d19a49.tag`:
    `3 cats`
  - `65a3f636e9a58cc2f658199bd1f731d9583b2fa183074f2e83aa3b3bb376a960.tag`:
    `1 clock`
  - `8f25f5e7b5497eaee683b0f53e33a5d4ce158ce60e9ed76b43d1ef5b65406d0e.tag`:
    `1 person`
  - `941b3d562238e25c3e65ca8c2483c9c8ec3ba2040d9a772eb59136b0daec112b.tag`:
    `1 sports ball`
  - `c1da45417742f9de0b118ff02e7657e85d66c19ed3f8287b634466c8277c740a.tag`:
    `1 person`
  - `d046fe89912ad238e124041960f1e41259ddfa16cd0945c702c286b54b8cce2c.tag`:
    `no detections`
  - `375a650373d0f6bc68e3e31d383b23d3bfb451129d27bcab9053fd0cfb23ce85.tag`:
    `2 persons, 1 potted plant, 1 laptop, 2 books`
